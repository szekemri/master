﻿using System.Web.UI;

namespace WebApplication3.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}