﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SG.IWIS.Adapter.Modawi.BmuViewer
{
    public struct BMUViewerXmlTagsForTreeView
    {
        public const string rootLayerNode = "bgs:Layer";
        public const string BEFLayerNode = "bgs:BGSBEFLayer";
        public const string ENTLayerNode = "bgs:BGSENTLayer";
        public const string ERZLayerNode = "bgs:BGSERZLayer"; 

    }
}