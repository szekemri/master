﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SG.IWIS.Adapter.Modawi.BmuViewer
{
    public struct BMUViewerXmlTagsForTreeView
    {
        public const string rootLayerNodeXmlTag = "Layer"; 
        public const string SignatureXmlTag = "Unterzeichners: ";
    }
}