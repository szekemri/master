﻿using com.sun.xml.@internal.txw2;
using de.consist.bmu.rule;
using de.itu.bmu.viewer;
using ikvm.runtime;
using org.apache.log4j;
using SG.Adapter.Modawi;
using SG.IWIS.Adapter.Modawi.BmuViewer;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;

namespace SG.IWIS.BMU
{
    public partial class BMU_Viewer : System.Web.UI.Page
    {
        //Uri will be used for getting Modawi Document GUID
        public static Uri _uri = HttpContext.Current.Request.Url;
        public string _modawiGUID = HttpUtility.ParseQueryString(_uri.Query).Get("docID");

        java.io.File htmlDocument = null;

        /// <summary>
        /// ASPX Page Loader method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //TODO: Create XML using modawwi method and save the file
            //TODO: Change file path below
            string pathOfXmlFile = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\test1.xml";
            
            //Load aspx page regions content
            this.loadTreeNodesInTreeView(pathOfXmlFile);
            this.loadHTMLContentInIFrame(pathOfXmlFile, null, null);
        }


        #region BMU Assembly initialization/configuration methods

        /// <summary>
        /// Configure and initialize BMU-Viewer assembly/classes (from API)
        /// </summary>
        private void InitializeAndConfigureBMUViewerAPIAssembly()
        {
            Startup.addBootClassPathAssembly(Assembly.Load("BMU-Viewer_2"));
            BasicConfigurator.configure();
            BMUController.init();
        }

        #endregion

        #region Tree View/Loader methods

        /// <summary>
        /// Load tree nodes (Root Node = Modawi document GUID, Layers, Signature)
        /// </summary>
        private void loadTreeNodesInTreeView(string XMLFilePath)
        {
            //declare and instantiate variables
            XmlDocument xmlDocument = this.LoadXmlDocumentContentFromFilePath(XMLFilePath);
            XmlNode xmlRootNode = xmlDocument.GetElementsByTagName(BMUViewerXmlTagsForTreeView.ENTLayerNode)[0];

            //add root node from XML document in Tree View
            AddParentNodeInTreeView(xmlRootNode);

            TreeNode treeRootNode = BMU_TreeView.Nodes[0];

            //xmlRootNode = FilterXMLChildNodes(xmlRootNode, xmlDocument);
            AddChildNodesInTreeView(xmlRootNode, treeRootNode);
        }

        /// <summary>
        /// Load document xml content into a XML File.
        /// </summary>
        /// <param name="xmlFilePath"></param>
        /// <returns></returns>
        private XmlDocument LoadXmlDocumentContentFromFilePath(string xmlFilePath)
        {
            XmlDocument xmlDocument = new XmlDocument();
            FileStream fileStream = new FileStream(xmlFilePath, FileMode.Open, FileAccess.Read);
            xmlDocument.Load(fileStream);
            return xmlDocument;
        }

        /// <summary>
        /// Load nodes into a System.XML.XMLDocument
        /// </summary>
        private void AddParentNodeInTreeView(XmlNode layerNodeText)
        {
            BMU_TreeView.Nodes.Clear();
            BMU_TreeView.Nodes.Add(new TreeNode(_modawiGUID));
        }

        /// <summary>
        /// Add nodes in BMU Tree View (layers, signature, etc.)
        /// </summary>
        /// <param name="inXmlNode"></param>
        /// <param name="inTreeNode"></param>
        private void AddChildNodesInTreeView(XmlNode inXmlNode, TreeNode inTreeRootNode)
        {
            //declare tree and xml node variables
            XmlNode xmlNode;
            TreeNode treeNode;
            XmlNodeList nodeList;

            inTreeRootNode.ChildNodes.Add(new TreeNode(inXmlNode.Name));

            //check if nodes exists in document XML structure
            if (inXmlNode.HasChildNodes)
            {
                //add childs to list
                nodeList = inXmlNode.ChildNodes;

                //loop throught xml nodes and add them into the Tree View.
                for (int i = 0; i <= nodeList.Count - 1; i++)
                {
                    xmlNode = inXmlNode.ChildNodes[i];
                    if (xmlNode.Name == BMUViewerXmlTagsForTreeView.ENTLayerNode)
                    {
                        inTreeRootNode.ChildNodes.Add(new TreeNode(xmlNode.LocalName));
                        treeNode = inTreeRootNode.ChildNodes[i];
                        AddChildNodesInTreeView(xmlNode, treeNode);
                    }
                }
            }
        }

        /// <summary>
        /// Change HTML Content from Iframe on tree view node click.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TreeView_OnSelectNodeHandler(object sender, EventArgs e)
        {

            //check if HTML document exists
            if (htmlDocument != null)
            {
                //TODO add missing parameters to display selected layer
                this.loadHTMLContentInIFrame(htmlDocument.getAbsolutePath(), null, null);
            }
        }

        #endregion

        #region IFrame content loader methods

        /// <summary>
        /// Load HTML content in Iframe based on the selected layer
        /// Load HTML content in Iframe based on the selected layer. 
        /// Based on the input parameter the HTML page content will be different.
        /// </summary>
        /// <param name="pathOfXmlFile"></param>
        private void loadHTMLContentInIFrame(string pathOfXmlFile, java.util.Map parameters, string range)
        {
            //initialize and configure BMU Viewer Assesmbly/API
            this.InitializeAndConfigureBMUViewerAPIAssembly();

            //generate HTML file for document layer view (transform method from BMU Controller should be used)
            htmlDocument = BMUController.transform(pathOfXmlFile, parameters, range);
            string htmlDocumentPath = htmlDocument.getAbsolutePath();
            
            //load html file into page iframe
            iframe.Attributes.Add("src", htmlDocumentPath);
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlRootNode"></param>
        /// <returns></returns>
        private XmlNode FilterXMLChildNodes(XmlNode xmlRootNode, XmlDocument xmlDocument)
        {
            XmlNodeList nodeList;
            nodeList = xmlRootNode.SelectNodes("BGSERZLayer");
                
            return xmlRootNode;
        }

        #endregion
    }
}
