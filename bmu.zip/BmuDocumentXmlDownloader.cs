﻿using EanvSoap;
using SG.Adapter.Modawi;
using SG.IWIS.Adapter.Modawi.Adapters.BmuViewer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;

namespace SG.IWIS.Adapter.Modawi.BMUViewer
{
    /// <summary>
    /// Provides functionalities for downloading XML documents.
    /// </summary>
    public class BmuDocumentXmlDownloader
    {
        private BmuViewerAdapter _bmuViewerAdapter;

        /// <summary>
        /// Initializes a instance of type <see cref="BmuDocumentDC"/>.
        /// </summary>
        public BmuDocumentXmlDownloader()
        {
            _bmuViewerAdapter = new BmuViewerAdapter();
        }

        /// <summary>
        /// Download XML document.
        /// </summary>
        /// <param name="documentGuid">The Modawi document GUID.</param>
        /// <returns>The BMU document data class <see cref="BmuDocumentDC"/> that contains the file name and path.</returns>
        public BmuDocumentDC DownloadXmlDocument(string documentGuid)
        {
            string xmlFileName = getXmlDocumentFileName(documentGuid);
            
            byte[] xmlDocumentContent = getXmlDocumentContentFromModawi(documentGuid);
            XmlDocument xmlDocument = loadXmlDocumentContent(xmlDocumentContent);
            string tempFolder = saveXmlDocument(xmlDocument, xmlFileName);
            BmuDocumentDC bmuDocumentDataClass = assignPathAndFileNameToDataClass(tempFolder, xmlFileName);

            return bmuDocumentDataClass;
        }

        /// <summary>
        /// Assign the path and file name to <see cref="BmuDocumentDC.Path"/> and <see cref="BmuDocumentDC.FileName"/> properties of the <seealso cref="BmuDocumentDC"/>.
        /// </summary>
        /// <param name="tempFolder">The temp folder.</param>
        /// <param name="xmlFileName">The XML file name.</param>
        /// <returns>The <see cref="BmuDocumentDC"/> data class with <see cref="BmuDocumentDC.Path"/>path and <see cref="BmuDocumentDC.FileName"/>.</returns>
        private BmuDocumentDC assignPathAndFileNameToDataClass(string tempFolder, string xmlFileName)
        {
            BmuDocumentDC bmuDocumentDataClass = new BmuDocumentDC();
            bmuDocumentDataClass.Path = tempFolder;
            bmuDocumentDataClass.FileName = xmlFileName;

            return bmuDocumentDataClass;
        }

        /// <summary>
        /// Save the XML document in the temp folder.
        /// </summary>
        /// <param name="xmlDocument">The XML document from Modawi.</param>
        /// <param name="xmlFileName">The XML document file name.</param>
        /// <returns>The path of temp folder.</returns>
        private string saveXmlDocument(XmlDocument xmlDocument, string xmlFileName)
        {
            string tempFolder = getTempFolder();
            string pathOfFileName = obtainPathOfFileName(tempFolder, xmlFileName);
            xmlDocument.Save(pathOfFileName);

            return tempFolder;
        }

        /// <summary>
        /// Obtain the path of file name.
        /// </summary>
        /// <param name="tempFolder">The temp folder path.</param>
        /// <param name="xmlFileName">The XML file name.</param>
        /// <returns>The path of file name.</returns>
        private string obtainPathOfFileName(string tempFolder, string xmlFileName)
        {
            return tempFolder + xmlFileName;
        }

        /// <summary>
        /// Get path of the temp folder.
        /// </summary>
        /// <returns>The path of the temp folder.</returns>
        private string getTempFolder()
        {
            return System.IO.Path.GetTempPath();
        }

        /// <summary>
        /// Convert the XML document content into <see cref="String"/>, and then load the content converted into <see cref="XmlDocument"/>.
        /// </summary>
        /// <param name="xmlDocumentContent">The XML document content received from Modawi.</param>
        /// <returns>The XML document with content received from Modawi.</returns>
        private XmlDocument loadXmlDocumentContent(byte[] xmlDocumentContent)
        {
            XmlDocument xmlDocument = new XmlDocument();
            string xmlDocumentContentConvertedToString = convertToStringXmlDocumentContent(xmlDocumentContent);
            xmlDocument.LoadXml(xmlDocumentContentConvertedToString);

            return xmlDocument;
        }

        /// <summary>
        /// Convert to <see cref="String"/> the content of the XML document received from Modawi.
        /// </summary>
        /// <param name="xmlDocumentContent">The XML document content received from Modawi.</param>
        /// <returns>The XML document content converted to <see cref="String"/>.</returns>
        private string convertToStringXmlDocumentContent(byte[] xmlDocumentContent)
        {
            return Encoding.UTF8.GetString(xmlDocumentContent);
        }

        /// <summary>
        /// Get the content of XML document from Modawi.
        /// </summary>
        /// <param name="documentGuid">The Modawi GUID of document.</param>
        /// <returns>The content of XML document.</returns>
        private byte[] getXmlDocumentContentFromModawi(string documentGuid)
        {
            return _bmuViewerAdapter.ModawiWebService.GetDocumentXml(documentGuid);
        }

        /// <summary>
        /// Get the file name of the document.
        /// </summary>
        /// <param name="documentGuid">The Modawi GUID of the document.</param>
        /// <returns>The file name of the document.</returns>
        private string getXmlDocumentFileName(string documentGuid)
        {
            anyType2anyTypeMap documentMetadata = getDocumentMetadata(documentGuid);
            string documentType = getDocumentType(documentMetadata);
            string documentNumber = getDocumentNumber(documentMetadata);

            return documentType + documentNumber + "_" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + ".xml";
        }

        /// <summary>
        /// Check if exists document number, and if there is get the document number from Modawi.
        /// </summary>
        /// <param name="documentMetadata">The metadata of the document obtained from Modawi.</param>
        /// <returns>The document number from Modawi if exists, otherwise return <see cref="string.Empty"/>.</returns>
        private string getDocumentNumber(anyType2anyTypeMap documentMetadata)
        {
            bool isDocumentNumber = checkForDocumentNumber(documentMetadata);
            if (isDocumentNumber)
            {
                return (documentMetadata.Find(x => x.key.ToString() == "docNummer")).value.ToString();
            }

            return String.Empty;
        }

        /// <summary>
        /// Check if exists document number.
        /// </summary>
        /// <param name="documentMetadata">The metadata of the document obtained from Modawi.</param>
        /// <returns>True if there is a document number, otherwise false.</returns>
        private bool checkForDocumentNumber(anyType2anyTypeMap documentMetadata)
        {
            return documentMetadata.Exists(x => x.key.ToString() == "docNummer");
        }

        /// <summary>
        /// Get document type.
        /// </summary>
        /// <param name="documentMetadata">The metadata of the document obtained from Modawi.</param>
        /// <returns>The document type.</returns>
        private string getDocumentType(anyType2anyTypeMap documentMetadata)
        {
            return (documentMetadata.Find(x => x.key.ToString() == "dokumentTyp")).value.ToString();
        }

        /// <summary>
        /// Get document metadata from Modawi.
        /// </summary>
        /// <param name="modawi_DocID"></param>
        /// <returns></returns>
        private anyType2anyTypeMap getDocumentMetadata(string modawi_DocID)
        {
            return _bmuViewerAdapter.ModawiWebService.GetDocumentMetadata(modawi_DocID);
        }
    }
}