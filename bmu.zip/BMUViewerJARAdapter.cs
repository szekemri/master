﻿using SG.IWIS.Log;
using System;
using System.Diagnostics;
using System.Web.UI.WebControls;

namespace SG.IWIS.Adapter.Modawi.BMUViewer
{
    public class BMUViewerJARAdapterTester : IBMUViewerJARAdapterLayer
    {
        /* TODO's
        //TODO - check if there are side effects, concerning the process
        //best practice for saving file path
        */
        public TreeView LoadTreeNodes()
        {
            TreeView _view = new TreeView();
            TreeNode _node = new TreeNode();
            _node.ChildNodes.Add(new TreeNode("asdasda_child"));
            _view.Nodes.Add(new TreeNode("ads"));
            return _view;
           
        }

        public void GetHTMLContent()
        {
            string path = @"C:\Users\muelldbe\Desktop\Bmu_JAVA\out\artifacts\Bmu_JAVA_jar\Bmu_JAVA.jar";
            Process p = new Process();
            // Redirect the output stream of the child process.
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            p.StartInfo.CreateNoWindow = false;
            p.StartInfo.FileName = "java.exe";
            p.StartInfo.Arguments = " -jar " + @"C:\Users\muelldbe\Desktop\Bmu_JAVA\out\artifacts\Bmu_JAVA_jar\Bmu_JAVA.jar";
            p.StartInfo.WorkingDirectory = @"C:\Program Files\Java\jre7\bin\";

            p.Start();

            //  Process.Start(@"C:/Program Files/Java/jre7/bin/java.exe -jar C:/Users/muelldbe/Desktop/Bmu_JAVA/out/artifacts/Bmu_JAVA_jar/Bmu_JAVA.jar");

            // Do not wait for the child process to exit before
            // reading to the end of its redirected stream.
            // p.WaitForExit();
            // Read the output stream first and then wait.
            string output = p.StandardOutput.ReadToEnd();
            string error = p.StandardError.ReadToEnd();

            int exitCode = p.ExitCode;

            //Console.WriteLine("output>>" + (String.IsNullOrEmpty(output) ? "(none)" : output));
            //Console.WriteLine("error>>" + (String.IsNullOrEmpty(error) ? "(none)" : error));
            //Console.WriteLine("ExitCode: " + exitCode.ToString(), "ExecuteCommand");

            FileEditor fEd = new FileEditor("JarTesting.txt");
            fEd.WriteToFile("********************Start*******************************************");
            fEd.WriteToFile("output: " + (String.IsNullOrEmpty(output) ? "(none)" : output));
            fEd.WriteToFile("error: " + (String.IsNullOrEmpty(error) ? "(none)" : error));
            fEd.WriteToFile("exitCode: " + exitCode.ToString());

            p.WaitForExit();

            p.Close();

            //using (Process process = Process.Start(start))
            //{
            //    //
            //    // Read in all the text from the process with the StreamReader.
            //    //
            //    using (StreamReader reader = process.StandardOutput)
            //    {
            //        string result = reader.ReadToEnd();
            //        Console.Write(result);
            //    }
            //}
        }               
    }

    public interface IBMUViewerJARAdapterLayer
    {
        TreeView LoadTreeNodes();
    }
}