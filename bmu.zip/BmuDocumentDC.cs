﻿using SG.Data;
using SG.IWIS.Adapter.Modawi.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SG.IWIS.Adapter.Modawi.BMUViewer
{
    public class BmuDocumentDC : ModawiDataBaseClass
    {
        // Path
        public string Path { get; set; }
        // FileName
        public string FileName { get; set; }
    }
}